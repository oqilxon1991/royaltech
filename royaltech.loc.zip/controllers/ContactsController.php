<?php
/**
 * Created by PhpStorm.
 * User: User
 * Date: 08.12.2017
 * Time: 12:15
 */

namespace app\controllers;
use app\models\Contacts;


class ContactsController extends AppController
{

}