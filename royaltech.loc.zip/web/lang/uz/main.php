<?php
return [
    'login' => 'Kirish',
    'price' => 'Narxi',
    'exit' => 'Chqish',
    'registration' => 'Ro`yhatdan o`tish',
    'cart' => 'Karzinka',
    'feedback' => 'Qayta aloqa',
    'search' => 'Qidirish',
    'categories' => 'Mahsulotlar toifalari',
    'bestseller' => 'Chegirmali mahsulotlar',
    'popular' => 'Tanlangan mahsulotlar',
    'newproducts' => 'Yangi mahsulotlar',
];