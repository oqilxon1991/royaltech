// JavaScript Document
 
  $(document).ready(function(){
  	"use strict";
	 if( $( window ).width() >= "768" ) {
		$(".header, .top-filter-sticky").sticky({topSpacing:0});	
    }

  });
  