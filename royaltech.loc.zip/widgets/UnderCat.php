<?php
/*namespace app\widgets;
use Yii;
use yii\base\Widget;
use app\models\Category;



class FiltrList extends Widget{


    public function run($parent_id){
        $undercat=Category::find()->where(['parent_id' => $parent_id])->all();

        return $this->render('filtrlist', compact( 'undercat'));
    }
}*/