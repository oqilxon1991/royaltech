<div class="col-xs-12 col-sm-4 col-md-4">
    <!-- f-weghit -->
    <div class="f-weghit">
        <h4>КОНТАКТЫ </h4>
        <ul>
            <li><i class="icon-location-pin icons" aria-hidden="true"></i>  <strong>Add: </strong> <?= $contacts['address']?> </li>
            <li><i class="icon-envelope-letter icons"></i>  <strong>Email: </strong> <?= $contacts['email']?> </li>
            <li><i class="icon-call-in icons"></i>  <strong>Phone Number: </strong> <?= $contacts['tel']?> </li>
        </ul>
    </div>
    <!-- /f-weghit -->
</div>