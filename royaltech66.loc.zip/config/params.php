<?php

return [
    'adminEmail' => 'oqilxon1991@gmail.com',
    'user.passwordResetTokenExpire' => 3600,
    'supportEmail' => 'oqilxon1991@gmail.com'
];

