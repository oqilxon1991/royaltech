<li>
    <a href="<?= \yii\helpers\Url::to(['category/view', 'id' => $category['id']])?>">
        <img src="/images/<?= $category['icon']?>" alt="menu-icon1" />&nbsp;&nbsp;<?= $category['name_ru']?>
    </a>
    <?php if( isset($category['childs']) ): ?>
    <ul>

            <?= $this->getMenuHtml($category['childs'])?>

    </ul>
    <?php endif;?>
</li>