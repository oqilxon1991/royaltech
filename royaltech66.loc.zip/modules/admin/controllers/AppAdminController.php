<?php
/**
 * Created by PhpStorm.
 * User: User
 * Date: 25.11.2017
 * Time: 18:28
 */

namespace app\modules\admin\controllers;

use yii\web\Controller;



class AppAdminController extends Controller{



}