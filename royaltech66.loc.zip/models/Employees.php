<?php
/**
 * Created by PhpStorm.
 * User: User
 * Date: 25.12.2017
 * Time: 16:07
 */

namespace app\models;


class Employees
{

}