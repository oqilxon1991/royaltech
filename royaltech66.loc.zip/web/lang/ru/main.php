<?php
return [
    'login' => 'Войти',
    'price' => 'Цена',
    'exit' => 'Выход',
    'registration' => 'Регистрация',
    'cart' => 'Корзина',
    'feedback' => 'Обратная связь',
    'search' => 'Поиск',
    'categories' => 'Категории продуктов',
    'bestseller' => 'Продукты со скидками',
    'popular' => 'Популярные продукты',
    'newproducts' => 'Новые продукты',
];