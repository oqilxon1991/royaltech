<?php

/* @var $this yii\web\View */

use yii\helpers\Html;
use app\controllers\Catalog;

$this->title = 'About';
$this->params['breadcrumbs'][] = $this->title;
?>
<div class="site-about">
    <h1><?= Html::encode($this->title) ?></h1>

    <?php
    $filter->setFilter([
        [
            'property' => 'color',
            'caption' => 'Color',
            'values' => [
                'Red',
                'Green',
                'Blue',
                'Black'
            ],
            'class' => 'horizontal'
        ],
        [
            'property' => 'size',
            'caption' => 'Size',
            'values' => [
                '45x45',
                '50x50',
                '60x60'
            ]
        ]
    ]);
    ?>
    <div>fwe ewrwe ewrw</div>
    <?php $filter->renderAjaxView($ajaxViewFile, ['testParam' => $testParam]);?>
</div>
